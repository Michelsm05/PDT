package interfaz.constantes;

public class Constantes {
	public final static String PDT = "PDT";
	
	
}

